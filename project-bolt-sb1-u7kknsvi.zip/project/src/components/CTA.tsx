import { Heart } from 'lucide-react';

interface CTAProps {
  onRequestPricing: () => void;
}

export default function CTA({ onRequestPricing }: CTAProps) {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-rose-900/90 via-amber-900/85 to-rose-900/90"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <Heart className="w-16 h-16 text-rose-200" strokeWidth={1.5} />
        </div>

        <h2 className="text-4xl md:text-5xl font-serif text-white mb-6 leading-tight">
          Celebrate Your Special Moments at Rosella Events
        </h2>

        <p className="text-xl text-rose-100 mb-10 font-light leading-relaxed max-w-2xl mx-auto">
          Let us help you create an unforgettable celebration filled with beauty,
          elegance, and cherished memories that will last a lifetime.
        </p>

        <button
          onClick={onRequestPricing}
          className="bg-white text-amber-900 hover:bg-amber-50 px-12 py-5 rounded-sm text-xl font-light tracking-wide transition-all duration-300 transform hover:scale-105 shadow-2xl"
        >
          Request Pricing & Availability
        </button>

        <p className="text-rose-200 mt-6 font-light italic text-lg">
          Let's make your celebration unforgettable.
        </p>
      </div>
    </section>
  );
}
