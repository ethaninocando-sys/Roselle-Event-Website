import { useState } from 'react';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    eventType: '',
    estimatedDate: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setFormData({
      name: '',
      email: '',
      phone: '',
      eventType: '',
      estimatedDate: '',
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-24 px-6 bg-gradient-to-b from-rose-50/30 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-gray-900 mb-4">
            Get in Touch
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto font-light">
            Ready to plan your special celebration? Contact us today to discuss your event
            and check availability.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="bg-white p-10 rounded-sm shadow-lg">
            <h3 className="text-2xl font-serif text-gray-900 mb-8">
              Send Us a Message
            </h3>

            {submitted && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-sm">
                <p className="text-green-800 font-light">
                  Thank you! We'll be in touch soon.
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2 font-light">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2 font-light">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2 font-light">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2 font-light">Event Type</label>
                <select
                  name="eventType"
                  value={formData.eventType}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
                >
                  <option value="">Select an event type</option>
                  <option value="wedding">Wedding</option>
                  <option value="quinceanera">Quinceañera</option>
                  <option value="sweet-sixteen">Sweet Sixteen</option>
                  <option value="baby-shower">Baby Shower</option>
                  <option value="birthday">Birthday Party</option>
                  <option value="other">Other Celebration</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2 font-light">Estimated Date</label>
                <input
                  type="date"
                  name="estimatedDate"
                  value={formData.estimatedDate}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-sm text-lg font-light tracking-wide transition-all duration-300 flex items-center justify-center gap-2 shadow-lg"
              >
                <Send className="w-5 h-5" />
                Send Inquiry
              </button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="bg-gradient-to-br from-amber-50 to-rose-50 p-10 rounded-sm shadow-lg">
              <h3 className="text-2xl font-serif text-gray-900 mb-8">
                Visit Us
              </h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-amber-700 flex-shrink-0 mt-1" strokeWidth={1.5} />
                  <div>
                    <h4 className="font-serif text-gray-900 mb-1">Location</h4>
                    <p className="text-gray-600 font-light">
                      San Juan, Texas<br />
                      Serving the Rio Grande Valley
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-amber-700 flex-shrink-0 mt-1" strokeWidth={1.5} />
                  <div>
                    <h4 className="font-serif text-gray-900 mb-1">Phone</h4>
                    <p className="text-gray-600 font-light">
                      Available upon request
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-amber-700 flex-shrink-0 mt-1" strokeWidth={1.5} />
                  <div>
                    <h4 className="font-serif text-gray-900 mb-1">Email</h4>
                    <p className="text-gray-600 font-light">
                      info@rosellaevents.com
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-sm shadow-lg text-center">
              <p className="text-gray-600 font-light italic leading-relaxed">
                "Creating unforgettable moments in the heart of the Rio Grande Valley,
                where elegance meets celebration."
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
