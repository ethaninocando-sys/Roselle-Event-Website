import { Clock, Star } from 'lucide-react';

export default function Packages() {
  const packages = [
    {
      duration: '4 Hours',
      description: 'Perfect for intimate celebrations and milestone moments',
      features: [
        'Complete venue setup',
        'Professional event coordination',
        'Elegant décor included',
        'Dedicated support staff',
      ],
    },
    {
      duration: '6 Hours',
      description: 'Ideal for grand celebrations requiring extended time',
      features: [
        'Extended venue access',
        'Full event coordination',
        'Premium décor package',
        'Attentive service throughout',
      ],
    },
  ];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-gray-900 mb-4">
            Event Packages
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
            Choose the perfect package for your celebration. Each option includes our full-service
            experience with meticulous attention to every detail.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
          {packages.map((pkg, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-rose-50 to-amber-50 p-10 rounded-sm shadow-lg border border-amber-200 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
            >
              <div className="flex items-center justify-center mb-6">
                <Clock className="w-12 h-12 text-amber-700" strokeWidth={1.5} />
              </div>
              <h3 className="text-3xl font-serif text-gray-900 mb-3 text-center">
                {pkg.duration}
              </h3>
              <p className="text-gray-600 text-center mb-8 font-light italic">
                {pkg.description}
              </p>

              <div className="space-y-4">
                {pkg.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" strokeWidth={2} fill="currentColor" />
                    <p className="text-gray-700 font-light">{feature}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <p className="text-gray-600 text-lg font-light italic max-w-2xl mx-auto">
            Every celebration at Rosella Events receives personalized attention and support
            from our experienced team, ensuring a seamless and memorable experience.
          </p>
        </div>
      </div>
    </section>
  );
}
