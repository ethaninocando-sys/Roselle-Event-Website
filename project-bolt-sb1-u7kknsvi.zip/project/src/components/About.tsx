import { Check } from 'lucide-react';

export default function About() {
  const features = [
    'Capacity up to 100 guests',
    'Full-service packages',
    'Designed for weddings, quinceañeras, sweet 16s, baby showers, birthdays, private parties',
    'Located in San Juan, Texas',
  ];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="relative h-[500px] rounded-sm overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Elegant venue interior"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <h2 className="text-4xl md:text-5xl font-serif text-gray-900 mb-6">
              A Venue Designed for Unforgettable Moments
            </h2>
            <div className="w-24 h-1 bg-amber-600 mb-8"></div>

            <p className="text-lg text-gray-600 mb-8 leading-relaxed font-light">
              Step into Rosella Events and discover an atmosphere of refined elegance.
              Our venue features sophisticated décor, romantic ambiance, and exquisite
              floral and gold design elements that create the perfect backdrop for your
              special celebration.
            </p>

            <p className="text-lg text-gray-600 mb-10 leading-relaxed font-light">
              Every detail has been thoughtfully curated to provide a luxurious setting
              that photographs beautifully and creates lasting memories for you and your guests.
            </p>

            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center mt-1">
                    <Check className="w-4 h-4 text-amber-700" strokeWidth={2.5} />
                  </div>
                  <p className="text-gray-700 text-lg font-light">{feature}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
