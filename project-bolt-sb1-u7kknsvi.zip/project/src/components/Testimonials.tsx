import { Quote, Star } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      text: 'Rosella Events made our wedding day absolutely perfect. The elegant atmosphere and attention to detail exceeded all our expectations.',
      author: 'Maria & Carlos',
      event: 'Wedding',
    },
    {
      text: "Our daughter's quinceañera was magical! The venue was stunning, and the staff made everything seamless. Highly recommend!",
      author: 'The Rodriguez Family',
      event: 'Quinceañera',
    },
    {
      text: 'From start to finish, the team at Rosella Events was professional and accommodating. Our celebration was everything we dreamed of.',
      author: 'Jessica M.',
      event: 'Sweet Sixteen',
    },
  ];

  return (
    <section className="py-24 px-6 bg-gradient-to-b from-white to-rose-50/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-gray-900 mb-4">
            What Our Clients Say
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto mb-6"></div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-sm shadow-lg hover:shadow-xl transition-all duration-300 relative"
            >
              <div className="absolute -top-4 left-8 bg-amber-600 rounded-full p-3">
                <Quote className="w-6 h-6 text-white" strokeWidth={2} />
              </div>

              <div className="flex gap-1 mb-4 mt-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-amber-500"
                    fill="currentColor"
                    strokeWidth={0}
                  />
                ))}
              </div>

              <p className="text-gray-700 mb-6 leading-relaxed font-light italic">
                "{testimonial.text}"
              </p>

              <div className="border-t border-gray-200 pt-4">
                <p className="font-serif text-gray-900 text-lg">
                  {testimonial.author}
                </p>
                <p className="text-amber-700 text-sm font-light">
                  {testimonial.event}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
