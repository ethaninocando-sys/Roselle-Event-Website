import { Sparkles } from 'lucide-react';

interface HeroProps {
  onRequestAvailability: () => void;
}

export default function Hero({ onRequestAvailability }: HeroProps) {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/2306281/pexels-photo-2306281.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/60"></div>
      </div>

      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto animate-fade-in">
        <div className="flex justify-center mb-6">
          <Sparkles className="w-12 h-12 text-amber-300" strokeWidth={1.5} />
        </div>

        <h1 className="text-5xl md:text-7xl font-serif text-white mb-6 leading-tight">
          Rosella Events
        </h1>

        <p className="text-2xl md:text-3xl text-amber-100 font-light mb-4 tracking-wide">
          Elegant Private Event Venue in San Juan, Texas
        </p>

        <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto mb-12 leading-relaxed font-light">
          A refined and intimate venue for weddings, quinceañeras, sweet sixteens,
          baby showers, and unforgettable celebrations.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={onRequestAvailability}
            className="bg-amber-600 hover:bg-amber-700 text-white px-10 py-4 rounded-sm text-lg font-light tracking-wide transition-all duration-300 transform hover:scale-105 shadow-xl"
          >
            Request Availability
          </button>
          <button className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-10 py-4 rounded-sm text-lg font-light tracking-wide transition-all duration-300">
            View Gallery
          </button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
}
