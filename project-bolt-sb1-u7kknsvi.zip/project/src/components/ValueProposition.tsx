import { Crown, Clock, Heart } from 'lucide-react';

export default function ValueProposition() {
  const features = [
    {
      icon: Crown,
      title: 'Boutique Private Venue',
      description: 'An intimate and exclusive setting for up to 100 guests, ensuring personalized attention for your celebration.',
    },
    {
      icon: Clock,
      title: 'Full-Service Packages',
      description: 'Choose between 4 or 6 hour event options, thoughtfully designed to accommodate your celebration needs.',
    },
    {
      icon: Heart,
      title: 'Seamless Experience',
      description: 'Professional service with meticulous attention to detail and beautiful décor that creates unforgettable moments.',
    },
  ];

  return (
    <section className="py-24 px-6 bg-gradient-to-b from-white to-rose-50/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-serif text-gray-900 mb-4">
            Why Choose Rosella Events
          </h2>
          <div className="w-24 h-1 bg-amber-600 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-10 rounded-sm shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border-t-4 border-amber-500"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-100 to-rose-100 rounded-full flex items-center justify-center">
                  <feature.icon className="w-8 h-8 text-amber-700" strokeWidth={1.5} />
                </div>
              </div>
              <h3 className="text-2xl font-serif text-gray-900 mb-4 text-center">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-center leading-relaxed font-light">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
