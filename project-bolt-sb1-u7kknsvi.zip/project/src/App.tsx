import Hero from './components/Hero';
import ValueProposition from './components/ValueProposition';
import About from './components/About';
import Gallery from './components/Gallery';
import Packages from './components/Packages';
import Testimonials from './components/Testimonials';
import CTA from './components/CTA';
import Contact from './components/Contact';

function App() {
  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    contactSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      <Hero onRequestAvailability={scrollToContact} />
      <ValueProposition />
      <About />
      <Gallery />
      <Packages />
      <Testimonials />
      <CTA onRequestPricing={scrollToContact} />
      <Contact />
    </div>
  );
}

export default App;
